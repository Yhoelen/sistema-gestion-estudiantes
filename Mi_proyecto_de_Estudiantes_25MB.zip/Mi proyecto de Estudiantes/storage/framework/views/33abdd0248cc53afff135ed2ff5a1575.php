<?php $__env->startSection('title', 'Estudiantes | Campus Gestión'); ?>
<?php $__env->startSection('content'); ?>
<div class="heading-row">
    <div><span class="mini-label">PANEL DE ADMINISTRACIÓN</span><h1>Estudiantes</h1><p class="muted">Administra y consulta la información académica.</p></div>
    <a href="<?php echo e(route('estudiantes.create')); ?>" class="btn btn-primary">＋ Nuevo estudiante</a>
</div>
<div class="stats-grid">
    <div class="stat-card"><span class="stat-icon">♧</span><div><p>Total de registros</p><strong><?php echo e($estudiantes->total()); ?></strong></div></div>
    <div class="stat-card"><span class="stat-icon stat-icon-blue">⌕</span><div><p>Resultados actuales</p><strong><?php echo e($estudiantes->count()); ?></strong></div></div>
    <div class="stat-card"><span class="stat-icon stat-icon-purple">✓</span><div><p>Estado del sistema</p><strong class="status-text">Activo</strong></div></div>
</div>
<section class="content-card">
    <div class="card-heading"><div><h2>Directorio académico</h2><p class="muted">Listado de estudiantes registrados en la base de datos.</p></div>
        <form method="GET" action="<?php echo e(route('estudiantes.index')); ?>" class="search-form">
            <input type="search" name="buscar" value="<?php echo e($buscar); ?>" placeholder="Buscar estudiante...">
            <button class="btn btn-dark" type="submit">Buscar</button>
            <?php if($buscar): ?><a class="clear-link" href="<?php echo e(route('estudiantes.index')); ?>">Limpiar</a><?php endif; ?>
        </form>
    </div>
    <div class="table-wrap"><table>
        <thead><tr><th>ESTUDIANTE</th><th>CORREO ELECTRÓNICO</th><th>EDAD</th><th>PROGRAMA ACADÉMICO</th><th>ACCIONES</th></tr></thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><div class="student-cell"><span class="avatar"><?php echo e(strtoupper(substr($estudiante->nombre, 0, 1))); ?></span><strong><?php echo e($estudiante->nombre); ?></strong></div></td>
                <td><?php echo e($estudiante->correo); ?></td><td><?php echo e($estudiante->edad); ?> años</td><td><span class="program-pill"><?php echo e($estudiante->programa); ?></span></td>
                <td><div class="actions"><a class="action-edit" href="<?php echo e(route('estudiantes.edit', $estudiante)); ?>">Editar</a>
                    <form method="POST" action="<?php echo e(route('estudiantes.destroy', $estudiante)); ?>" onsubmit="return confirm('¿Seguro que deseas eliminar a <?php echo e(addslashes($estudiante->nombre)); ?>? Esta acción no se puede deshacer.');">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="action-delete" type="submit">Eliminar</button>
                    </form></div></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="5" class="empty-state"><div class="empty-icon">⌕</div><strong>No se encontraron estudiantes</strong><p>Registra un estudiante o cambia el criterio de búsqueda.</p></td></tr>
        <?php endif; ?>
        </tbody>
    </table></div>
    <div class="pagination-wrap"><?php echo e($estudiantes->links()); ?></div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Mi proyecto de Estudiantes\resources\views/estudiantes/index.blade.php ENDPATH**/ ?>