<?php $__env->startSection('title', 'Editar estudiante | Campus Gestión'); ?>
<?php $__env->startSection('content'); ?>
<div class="form-page-head"><a href="<?php echo e(route('estudiantes.index')); ?>" class="back-link">← Volver al directorio</a><span class="mini-label">ACTUALIZACIÓN DE DATOS</span><h1>Editar estudiante</h1><p class="muted">Modifica la información de <?php echo e($estudiante->nombre); ?>.</p></div>
<section class="content-card form-card">
    <div class="form-section-title"><span class="section-number">02</span><div><h2>Información personal y académica</h2><p class="muted">Verifica los cambios antes de guardar.</p></div></div>
    <form method="POST" action="<?php echo e(route('estudiantes.update', $estudiante)); ?>" class="student-form">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <?php echo $__env->make('estudiantes.partials.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="form-actions"><a class="btn btn-outline" href="<?php echo e(route('estudiantes.index')); ?>">Cancelar</a><button class="btn btn-primary" type="submit">Actualizar información <span>→</span></button></div>
    </form>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Mi proyecto de Estudiantes\resources\views/estudiantes/edit.blade.php ENDPATH**/ ?>