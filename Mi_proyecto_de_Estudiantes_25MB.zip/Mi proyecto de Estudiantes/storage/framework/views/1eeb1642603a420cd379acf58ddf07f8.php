<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Mi proyecto de Estudiantes'); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <?php if(session('docente_autenticado')): ?>
    <header class="topbar">
        <a class="brand" href="<?php echo e(route('estudiantes.index')); ?>"><span class="brand-mark">E</span><span>Campus<span class="brand-light">Gestión</span></span></a>
        <div class="topbar-right">
            <span class="user-chip"><span class="user-dot"></span><?php echo e(session('docente_nombre')); ?></span>
            <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button class="btn-logout" type="submit">Cerrar sesión</button></form>
        </div>
    </header>
    <?php endif; ?>

    <main class="page-wrap">
        <?php if(session('success')): ?> <div class="alert alert-success"><?php echo e(session('success')); ?></div> <?php endif; ?>
        <?php if(session('error')): ?> <div class="alert alert-error"><?php echo e(session('error')); ?></div> <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-error"><strong>Revisa la información:</strong><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer class="footer">Mi proyecto de Estudiantes <span>·</span> Sistema académico de registro</footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Mi proyecto de Estudiantes\resources\views/layouts/app.blade.php ENDPATH**/ ?>