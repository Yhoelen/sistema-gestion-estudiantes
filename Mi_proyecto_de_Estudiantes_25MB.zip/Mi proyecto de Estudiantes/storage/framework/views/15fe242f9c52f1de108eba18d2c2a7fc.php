<div class="form-grid">
    <label>Nombre completo <span class="required">*</span><input type="text" name="nombre" value="<?php echo e(old('nombre', $estudiante->nombre ?? '')); ?>" placeholder="Ej. Ana María Rodríguez" minlength="3" maxlength="120" required></label>
    <label>Correo electrónico <span class="required">*</span><input type="email" name="correo" value="<?php echo e(old('correo', $estudiante->correo ?? '')); ?>" placeholder="estudiante@correo.com" maxlength="150" required></label>
    <label>Edad <span class="required">*</span><input type="number" name="edad" value="<?php echo e(old('edad', $estudiante->edad ?? '')); ?>" placeholder="Ej. 20" min="16" max="100" required><small>La edad permitida es de 16 a 100 años.</small></label>
    <label>Programa académico <span class="required">*</span>
        <select name="programa" required>
            <option value="">Selecciona un programa</option>
            <?php $__currentLoopData = ['Ingeniería Informática','Ingeniería de Sistemas','Administración de Empresas','Contaduría Pública','Psicología','Otro']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($programa); ?>" <?php if(old('programa', $estudiante->programa ?? '') === $programa): echo 'selected'; endif; ?>><?php echo e($programa); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </label>
</div>
<?php /**PATH C:\xampp\htdocs\Mi proyecto de Estudiantes\resources\views/estudiantes/partials/form.blade.php ENDPATH**/ ?>