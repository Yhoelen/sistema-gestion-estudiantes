@extends('layouts.app')
@section('title', 'Editar estudiante | Campus Gestión')
@section('content')
<div class="form-page-head"><a href="{{ route('estudiantes.index') }}" class="back-link">← Volver al directorio</a><span class="mini-label">ACTUALIZACIÓN DE DATOS</span><h1>Editar estudiante</h1><p class="muted">Modifica la información de {{ $estudiante->nombre }}.</p></div>
<section class="content-card form-card">
    <div class="form-section-title"><span class="section-number">02</span><div><h2>Información personal y académica</h2><p class="muted">Verifica los cambios antes de guardar.</p></div></div>
    <form method="POST" action="{{ route('estudiantes.update', $estudiante) }}" class="student-form">
        @csrf @method('PUT')
        @include('estudiantes.partials.form')
        <div class="form-actions"><a class="btn btn-outline" href="{{ route('estudiantes.index') }}">Cancelar</a><button class="btn btn-primary" type="submit">Actualizar información <span>→</span></button></div>
    </form>
</section>
@endsection
