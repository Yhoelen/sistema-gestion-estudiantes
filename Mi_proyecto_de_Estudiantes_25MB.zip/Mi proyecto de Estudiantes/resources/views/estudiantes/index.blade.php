@extends('layouts.app')
@section('title', 'Estudiantes | Campus Gestión')
@section('content')
<div class="heading-row">
    <div><span class="mini-label">PANEL DE ADMINISTRACIÓN</span><h1>Estudiantes</h1><p class="muted">Administra y consulta la información académica.</p></div>
    <a href="{{ route('estudiantes.create') }}" class="btn btn-primary">＋ Nuevo estudiante</a>
</div>
<div class="stats-grid">
    <div class="stat-card"><span class="stat-icon">♧</span><div><p>Total de registros</p><strong>{{ $estudiantes->total() }}</strong></div></div>
    <div class="stat-card"><span class="stat-icon stat-icon-blue">⌕</span><div><p>Resultados actuales</p><strong>{{ $estudiantes->count() }}</strong></div></div>
    <div class="stat-card"><span class="stat-icon stat-icon-purple">✓</span><div><p>Estado del sistema</p><strong class="status-text">Activo</strong></div></div>
</div>
<section class="content-card">
    <div class="card-heading"><div><h2>Directorio académico</h2><p class="muted">Listado de estudiantes registrados en la base de datos.</p></div>
        <form method="GET" action="{{ route('estudiantes.index') }}" class="search-form">
            <input type="search" name="buscar" value="{{ $buscar }}" placeholder="Buscar estudiante...">
            <button class="btn btn-dark" type="submit">Buscar</button>
            @if($buscar)<a class="clear-link" href="{{ route('estudiantes.index') }}">Limpiar</a>@endif
        </form>
    </div>
    <div class="table-wrap"><table>
        <thead><tr><th>ESTUDIANTE</th><th>CORREO ELECTRÓNICO</th><th>EDAD</th><th>PROGRAMA ACADÉMICO</th><th>ACCIONES</th></tr></thead>
        <tbody>
        @forelse($estudiantes as $estudiante)
            <tr>
                <td><div class="student-cell"><span class="avatar">{{ strtoupper(substr($estudiante->nombre, 0, 1)) }}</span><strong>{{ $estudiante->nombre }}</strong></div></td>
                <td>{{ $estudiante->correo }}</td><td>{{ $estudiante->edad }} años</td><td><span class="program-pill">{{ $estudiante->programa }}</span></td>
                <td><div class="actions"><a class="action-edit" href="{{ route('estudiantes.edit', $estudiante) }}">Editar</a>
                    <form method="POST" action="{{ route('estudiantes.destroy', $estudiante) }}" onsubmit="return confirm('¿Seguro que deseas eliminar a {{ addslashes($estudiante->nombre) }}? Esta acción no se puede deshacer.');">
                        @csrf @method('DELETE')<button class="action-delete" type="submit">Eliminar</button>
                    </form></div></td>
            </tr>
        @empty
            <tr><td colspan="5" class="empty-state"><div class="empty-icon">⌕</div><strong>No se encontraron estudiantes</strong><p>Registra un estudiante o cambia el criterio de búsqueda.</p></td></tr>
        @endforelse
        </tbody>
    </table></div>
    <div class="pagination-wrap">{{ $estudiantes->links() }}</div>
</section>
@endsection
