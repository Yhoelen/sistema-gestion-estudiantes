<div class="form-grid">
    <label>Nombre completo <span class="required">*</span><input type="text" name="nombre" value="{{ old('nombre', $estudiante->nombre ?? '') }}" placeholder="Ej. Ana María Rodríguez" minlength="3" maxlength="120" required></label>
    <label>Correo electrónico <span class="required">*</span><input type="email" name="correo" value="{{ old('correo', $estudiante->correo ?? '') }}" placeholder="estudiante@correo.com" maxlength="150" required></label>
    <label>Edad <span class="required">*</span><input type="number" name="edad" value="{{ old('edad', $estudiante->edad ?? '') }}" placeholder="Ej. 20" min="16" max="100" required><small>La edad permitida es de 16 a 100 años.</small></label>
    <label>Programa académico <span class="required">*</span>
        <select name="programa" required>
            <option value="">Selecciona un programa</option>
            @foreach(['Ingeniería Informática','Ingeniería de Sistemas','Administración de Empresas','Contaduría Pública','Psicología','Otro'] as $programa)
                <option value="{{ $programa }}" @selected(old('programa', $estudiante->programa ?? '') === $programa)>{{ $programa }}</option>
            @endforeach
        </select>
    </label>
</div>
