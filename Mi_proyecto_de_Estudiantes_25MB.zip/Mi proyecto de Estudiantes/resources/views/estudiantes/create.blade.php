@extends('layouts.app')
@section('title', 'Nuevo estudiante | Campus Gestión')
@section('content')
<div class="form-page-head"><a href="{{ route('estudiantes.index') }}" class="back-link">← Volver al directorio</a><span class="mini-label">REGISTRO ACADÉMICO</span><h1>Nuevo estudiante</h1><p class="muted">Completa los datos para incorporar un estudiante al sistema.</p></div>
<section class="content-card form-card">
    <div class="form-section-title"><span class="section-number">01</span><div><h2>Información personal y académica</h2><p class="muted">Los campos marcados son obligatorios.</p></div></div>
    <form method="POST" action="{{ route('estudiantes.store') }}" class="student-form">
        @csrf
        @include('estudiantes.partials.form')
        <div class="form-actions"><a class="btn btn-outline" href="{{ route('estudiantes.index') }}">Cancelar</a><button class="btn btn-primary" type="submit">Guardar estudiante <span>→</span></button></div>
    </form>
</section>
@endsection
