@extends('layouts.app')
@section('title', 'Acceso | Campus Gestión')
@section('content')
<section class="login-shell">
    <div class="login-visual">
        <div class="visual-orb orb-one"></div><div class="visual-orb orb-two"></div>
        <div class="visual-content">
            <div class="visual-icon">✦</div>
            <p class="eyebrow">PLATAFORMA ACADÉMICA</p>
            <h1>Organiza el talento.<br><em>Impulsa el futuro.</em></h1>
            <p class="visual-copy">Una forma sencilla y segura de administrar la información de tus estudiantes.</p>
            <div class="visual-foot"><span></span> Gestión académica en un solo lugar</div>
        </div>
    </div>
    <div class="login-panel">
        <div class="panel-inner">
            <span class="mini-label">BIENVENIDO DE NUEVO</span>
            <h2>Iniciar sesión</h2>
            <p class="muted">Ingresa tus credenciales para acceder al sistema.</p>
            <form method="POST" action="{{ route('login.ingresar') }}" class="form-stack">
                @csrf
                <label>Correo electrónico
                    <input type="email" name="correo" value="{{ old('correo') }}" placeholder="docente@demo.com" required autofocus>
                </label>
                <label>Contraseña
                    <input type="password" name="password" placeholder="Ingresa tu contraseña" required>
                </label>
                <button class="btn btn-primary btn-full" type="submit">Ingresar al sistema <span>→</span></button>
            </form>
            <p class="login-note">Acceso exclusivo para el docente o administrador.</p>
        </div>
    </div>
</section>
@endsection
