<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Mi proyecto de Estudiantes')</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
    @if(session('docente_autenticado'))
    <header class="topbar">
        <a class="brand" href="{{ route('estudiantes.index') }}"><span class="brand-mark">E</span><span>Campus<span class="brand-light">Gestión</span></span></a>
        <div class="topbar-right">
            <span class="user-chip"><span class="user-dot"></span>{{ session('docente_nombre') }}</span>
            <form method="POST" action="{{ route('logout') }}">@csrf<button class="btn-logout" type="submit">Cerrar sesión</button></form>
        </div>
    </header>
    @endif

    <main class="page-wrap">
        @if(session('success')) <div class="alert alert-success">{{ session('success') }}</div> @endif
        @if(session('error')) <div class="alert alert-error">{{ session('error') }}</div> @endif
        @if($errors->any())
            <div class="alert alert-error"><strong>Revisa la información:</strong><ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>
        @endif
        @yield('content')
    </main>
    <footer class="footer">Mi proyecto de Estudiantes <span>·</span> Sistema académico de registro</footer>
</body>
</html>
