# Mi proyecto de Estudiantes

Sistema web de gestión académica desarrollado con **Laravel 12**, PHP y MySQL. XAMPP se utiliza para ejecutar el servicio MySQL (y opcionalmente Apache); Laravel ejecuta la aplicación.

## Funcionalidades

- Inicio y cierre de sesión para el docente.
- Registro de estudiantes.
- Listado y búsqueda por nombre, correo o programa.
- Edición de los datos del estudiante.
- Eliminación con confirmación del navegador.
- Validación del servidor: campos obligatorios, correo válido y único, edad entre 16 y 100 y programa dentro del catálogo.
- Persistencia de los registros en MySQL.

## Requisitos

- Windows 10/11.
- XAMPP con MySQL/MariaDB.
- PHP 8.2 o superior, con extensiones habituales de Laravel habilitadas.
- Composer 2.
- Navegador web.

> Importante: el ZIP contiene el código fuente del proyecto, no la carpeta `vendor`. Debes instalar las dependencias con Composer en tu equipo. Eso evita entregar dependencias pesadas y permite que Composer las prepare para tu versión de PHP.

## Instalación en Windows con XAMPP

1. Descomprime `Mi proyecto de Estudiantes.zip` en una ruta sencilla, por ejemplo `C:\xampp\htdocs\Mi proyecto de Estudiantes`.
2. Abre XAMPP Control Panel e inicia **MySQL**. Apache no es obligatorio si usarás `php artisan serve`.
3. Entra a `http://localhost/phpmyadmin`.
4. Crea una base de datos llamada `mi_proyecto_estudiantes` con cotejamiento `utf8mb4_unicode_ci`.
5. Abre PowerShell dentro de la carpeta del proyecto.
6. Comprueba `php -v` y `composer --version`. Si Windows no reconoce `php`, agrega `C:\xampp\php` al PATH o ejecuta los comandos usando la ruta completa de `php.exe`.
7. Instala dependencias:

   ```powershell
   composer install
   ```

8. Crea el archivo de entorno:

   ```powershell
   Copy-Item .env.example .env
   ```

9. Abre `.env` y verifica estos valores para XAMPP. Si tu MySQL tiene contraseña, escríbela en `DB_PASSWORD`.

   ```env
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=mi_proyecto_estudiantes
   DB_USERNAME=root
   DB_PASSWORD=
   ```

10. Genera la clave y crea las tablas y el usuario docente:

   ```powershell
   php artisan key:generate
   php artisan migrate --seed
   ```

11. Inicia Laravel:

   ```powershell
   php artisan serve
   ```

12. Abre `http://127.0.0.1:8000`.

## Acceso de demostración

- Correo: `docente@demo.com`
- Contraseña: `Estudiantes2026!`

Son credenciales iniciales para una base de laboratorio. Cámbialas antes de cualquier despliegue real. Para cambiar los valores iniciales, edita `DOCENTE_EMAIL`, `DOCENTE_CLAVE` y `DOCENTE_NOMBRE` en `.env` antes de ejecutar el seeder.

## Flujo para demostrar al docente

1. Inicia sesión con el usuario de demostración.
2. Registra un estudiante ficticio con un correo nuevo.
3. Comprueba que aparece en el directorio.
4. Busca por nombre o correo.
5. Edita el programa académico y verifica que se actualizó la misma fila.
6. Intenta registrar el mismo correo: debe aparecer un error y no debe crearse un duplicado.
7. Intenta registrar edad 15: Laravel debe rechazarla.
8. Elimina únicamente el registro ficticio y confirma que desaparece.
9. Cierra sesión y comprueba que el directorio solicita autenticación.

## Rutas principales

| Método | Ruta | Acción |
|---|---|---|
| GET | `/login` | Mostrar acceso |
| POST | `/login` | Validar e iniciar sesión |
| POST | `/logout` | Cerrar sesión |
| GET | `/estudiantes` | Listar y buscar |
| GET | `/estudiantes/create` | Mostrar formulario |
| POST | `/estudiantes` | Guardar estudiante |
| GET | `/estudiantes/{id}/edit` | Mostrar edición |
| PUT/PATCH | `/estudiantes/{id}` | Actualizar |
| DELETE | `/estudiantes/{id}` | Eliminar |

## Recorrido técnico

**Vista Blade → ruta web → controlador → validación → modelo Eloquent → MySQL → redirección a la vista.**

- `routes/web.php`: define las rutas.
- `EstudianteController.php`: implementa el CRUD y las validaciones.
- `Estudiante.php`: representa la tabla `estudiantes`.
- `database/migrations`: crea las tablas.
- `DocenteSeeder.php`: crea el usuario de demostración.
- `resources/views`: contiene las pantallas Blade.
- `DocenteAutenticado.php`: protege el directorio para que solo entre un docente autenticado.

## Comandos útiles para revisar

```powershell
php artisan route:list
php artisan migrate:status
php artisan db:seed --class=DocenteSeeder
php artisan serve
```

Si necesitas reiniciar por completo la base de laboratorio (esto borra sus registros), usa `php artisan migrate:fresh --seed` únicamente después de confirmar que no hay datos que debas conservar.

## Pruebas

Consulta `registro-pruebas.md` y completa el resultado real de cada caso en tu computador. No marques una prueba como correcta sin ejecutarla.
