# Entrega final — Mi proyecto de Estudiantes

- **Proyecto:** Mi proyecto de Estudiantes
- **Tecnologías:** Laravel 12, PHP, MySQL y XAMPP.
- **Repositorio:** [Pegar aquí el enlace real del repositorio, si se utiliza GitHub]
- **Commit presentado:** [Pegar aquí el identificador real del commit]
- **Autor / integrantes:** [Completar]
- **Fecha:** [Completar]

## Funciones implementadas en el código

- Acceso de docente.
- Registro, consulta, búsqueda, edición y eliminación de estudiantes.
- Validación de campos, edad, programa y correo único.
- Almacenamiento persistente en MySQL.

## Estado de pruebas

Adjuntar el `registro-pruebas.md` completado con resultados observados. No afirmar que una prueba fue superada si no se ejecutó.

## Reflexión

Explicar qué aprendiste al conectar una vista Blade con una ruta, un controlador, un modelo Eloquent y una tabla MySQL.
