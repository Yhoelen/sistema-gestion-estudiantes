# Registro de pruebas — Mi proyecto de Estudiantes

Completa la columna de resultado obtenido durante el ensayo real.

| Caso | Resultado esperado | Resultado obtenido | Estado |
|---|---|---|---|
| Inicio de sesión con credenciales válidas | Entra al directorio | Pendiente | Pendiente |
| Inicio de sesión con contraseña incorrecta | Muestra error y no permite entrar | Pendiente | Pendiente |
| Alta con datos válidos | Crea una fila en MySQL y aparece en el listado | Pendiente | Pendiente |
| Correo repetido | Rechaza el registro y no duplica la fila | Pendiente | Pendiente |
| Edad 15 | Rechaza el registro | Pendiente | Pendiente |
| Correo con formato inválido | Rechaza el registro | Pendiente | Pendiente |
| Programa no incluido en el catálogo | Rechaza el registro | Pendiente | Pendiente |
| Búsqueda sin coincidencias | Muestra un listado vacío comprensible | Pendiente | Pendiente |
| Edición manteniendo el mismo correo | Actualiza el mismo estudiante | Pendiente | Pendiente |
| Edición usando correo de otro estudiante | Rechaza el cambio | Pendiente | Pendiente |
| Cancelar confirmación de eliminación | Conserva el registro | Pendiente | Pendiente |
| Confirmar eliminación | Borra solo el estudiante seleccionado | Pendiente | Pendiente |
| Abrir directorio sin iniciar sesión | Redirige al acceso | Pendiente | Pendiente |
| Cerrar sesión | Termina la sesión y protege el directorio | Pendiente | Pendiente |

## Dificultad resuelta

Describe un problema que hayas encontrado, qué lo causaba, qué cambio realizaste y cómo comprobaste que quedó solucionado.

## Aporte personal

Indica qué archivos revisaste o modificaste y explica qué responsabilidad cumple cada uno.

## Mejora futura

Propón una mejora que todavía no esté implementada, por ejemplo: exportar el directorio a Excel o PDF.
