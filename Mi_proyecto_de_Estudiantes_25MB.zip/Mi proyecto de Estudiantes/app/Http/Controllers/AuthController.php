<?php

namespace App\Http\Controllers;

use App\Models\Docente;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function formulario()
    {
        return view('auth.login');
    }

    public function ingresar(Request $request)
    {
        $datos = $request->validate([
            'correo' => ['required', 'email'],
            'password' => ['required', 'string'],
        ]);

        $docente = Docente::where('correo', $datos['correo'])->first();

        if (!$docente || !Hash::check($datos['password'], $docente->password)) {
            return back()->withErrors(['correo' => 'Correo o contraseña incorrectos.'])
                ->onlyInput('correo');
        }

        $request->session()->regenerate();
        $request->session()->put([
            'docente_autenticado' => true,
            'docente_nombre' => $docente->nombre,
            'docente_id' => $docente->id,
        ]);

        return redirect()->route('estudiantes.index')->with('success', 'Bienvenido al sistema.');
    }

    public function salir(Request $request)
    {
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login')->with('success', 'Sesión cerrada correctamente.');
    }
}
