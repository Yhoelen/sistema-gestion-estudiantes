<?php

namespace App\Http\Controllers;

use App\Models\Estudiante;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class EstudianteController extends Controller
{
    public function index(Request $request)
    {
        $buscar = trim((string) $request->query('buscar', ''));

        $estudiantes = Estudiante::query()
            ->when($buscar, function ($query, $buscar) {
                $query->where(function ($subquery) use ($buscar) {
                    $subquery->where('nombre', 'like', "%{$buscar}%")
                        ->orWhere('correo', 'like', "%{$buscar}%")
                        ->orWhere('programa', 'like', "%{$buscar}%");
                });
            })
            ->orderByDesc('id')
            ->paginate(10)
            ->withQueryString();

        return view('estudiantes.index', compact('estudiantes', 'buscar'));
    }

    public function create()
    {
        return view('estudiantes.create');
    }

    public function store(Request $request)
    {
        $datos = $request->validate([
            'nombre' => ['required', 'string', 'min:3', 'max:120'],
            'correo' => ['required', 'email', 'max:150', 'unique:estudiantes,correo'],
            'edad' => ['required', 'integer', 'min:16', 'max:100'],
            'programa' => ['required', 'string', 'min:2', 'max:120', Rule::in([
                'Ingeniería Informática',
                'Ingeniería de Sistemas',
                'Administración de Empresas',
                'Contaduría Pública',
                'Psicología',
                'Otro'
            ])],
        ], [
            'nombre.required' => 'El nombre del estudiante es obligatorio.',
            'correo.unique' => 'Ya existe un estudiante registrado con ese correo.',
            'edad.min' => 'La edad mínima permitida es 16 años.',
            'programa.in' => 'Selecciona un programa válido de la lista.',
        ]);

        Estudiante::create($datos);

        return redirect()->route('estudiantes.index')->with('success', 'Estudiante registrado correctamente.');
    }

    public function edit(Estudiante $estudiante)
    {
        return view('estudiantes.edit', compact('estudiante'));
    }

    public function update(Request $request, Estudiante $estudiante)
    {
        $datos = $request->validate([
            'nombre' => ['required', 'string', 'min:3', 'max:120'],
            'correo' => ['required', 'email', 'max:150', Rule::unique('estudiantes', 'correo')->ignore($estudiante->id)],
            'edad' => ['required', 'integer', 'min:16', 'max:100'],
            'programa' => ['required', 'string', 'min:2', 'max:120', Rule::in([
                'Ingeniería Informática',
                'Ingeniería de Sistemas',
                'Administración de Empresas',
                'Contaduría Pública',
                'Psicología',
                'Otro'
            ])],
        ], [
            'correo.unique' => 'Ese correo ya está asociado a otro estudiante.',
            'edad.min' => 'La edad mínima permitida es 16 años.',
            'programa.in' => 'Selecciona un programa válido de la lista.',
        ]);

        $estudiante->update($datos);

        return redirect()->route('estudiantes.index')->with('success', 'Información actualizada correctamente.');
    }

    public function destroy(Estudiante $estudiante)
    {
        $estudiante->delete();

        return redirect()->route('estudiantes.index')->with('success', 'Estudiante eliminado correctamente.');
    }
}
