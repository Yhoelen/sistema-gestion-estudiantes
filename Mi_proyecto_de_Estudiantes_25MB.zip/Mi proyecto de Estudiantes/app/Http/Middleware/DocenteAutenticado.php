<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class DocenteAutenticado
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!$request->session()->get('docente_autenticado')) {
            return redirect()->route('login')->with('error', 'Inicia sesión para continuar.');
        }

        return $next($request);
    }
}
