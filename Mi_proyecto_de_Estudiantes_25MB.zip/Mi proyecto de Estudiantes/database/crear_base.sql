-- Opcional: crear la base desde phpMyAdmin o ejecutar este SQL.
CREATE DATABASE IF NOT EXISTS mi_proyecto_estudiantes
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
