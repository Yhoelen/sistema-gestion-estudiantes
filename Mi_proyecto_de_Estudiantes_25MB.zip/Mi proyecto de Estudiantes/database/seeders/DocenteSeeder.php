<?php

namespace Database\Seeders;

use App\Models\Docente;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DocenteSeeder extends Seeder
{
    public function run(): void
    {
        Docente::updateOrCreate(
            ['correo' => env('DOCENTE_EMAIL', 'docente@demo.com')],
            [
                'nombre' => env('DOCENTE_NOMBRE', 'Docente Administrador'),
                'password' => Hash::make(env('DOCENTE_CLAVE', 'Estudiantes2026!')),
            ]
        );
    }
}
