<?php

use Illuminate\Support\Facades\Artisan;

Artisan::command('proyecto:info', function () {
    $this->info('Mi proyecto de Estudiantes está configurado.');
})->purpose('Muestra información básica del proyecto');
