<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\EstudianteController;
use Illuminate\Support\Facades\Route;

Route::get('/', fn () => redirect()->route('login'));

Route::get('/login', [AuthController::class, 'formulario'])->name('login');
Route::post('/login', [AuthController::class, 'ingresar'])->name('login.ingresar');

Route::middleware('docente')->group(function () {
    Route::post('/logout', [AuthController::class, 'salir'])->name('logout');
    Route::resource('estudiantes', EstudianteController::class)->except(['show']);
});
